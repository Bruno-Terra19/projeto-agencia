/**
 * 504. Base 7
 * https://leetcode.com/problems/base-7/
 * Difficulty: Easy
 *
 * Given an integer num, return a string of its base 7 representation.
 */

/**
 * @param {number} num
 * @return {string}
 */
var convertToBase7 = function(num) {
  return num.toString(7);
};
